/**
 * Mobility First - Global Name Resolution Service (GNS)
 * Copyright (C) 2013 University of Massachusetts - Emmanuel Cecchet.
 * Contact: cecchet@cs.umass.edu
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 *
 * Initial developer(s): Emmanuel Cecchet.
 * Contributor(s): ______________________.
 */

package edu.umass.cs.msocket.multicast;

import java.io.InputStream;
import java.io.OutputStream;

public class MSocketGroupWriter {
	
	//public static double CHECK_RADIUS = 75;
	private MSocketGroupWriterInputStream mcIn  =  null;
	private MSocketGroupWriterOutputStream mcOut = null;
	private String writerName ="";
	private MSocketGroupWriterInternals msocketGroupWriterInternalsObj = null;
		
	
	/**
	 * 
	 * TODO: MultiCastWriter definition.
	 * 
	 * @param groupName: multicast groupName
	 * @throws Exception 
	 */
	public MSocketGroupWriter(String writerName) throws Exception {
		this.writerName = writerName;
		msocketGroupWriterInternalsObj = new MSocketGroupWriterInternals(writerName);
	}
	
	/**
	 * color:red type select call
	 * TODO: connect definition.
	 * 
	 * @param groupName
	 * @throws Exception
	 */
	public void connect(String groupName) throws Exception {
		msocketGroupWriterInternalsObj.setGroupName(groupName);
		msocketGroupWriterInternalsObj.createGroup();
		//msocketGroupWriterInternalsObj.startGroupMaintainThread();
	}
	
	public void setLocation(double Lat, double Longi) {
		msocketGroupWriterInternalsObj.setLocation(Lat, Longi);
	}
	
	public void setRadius(double Radius) {
		msocketGroupWriterInternalsObj.setRadius(Radius);
	}
	
	public double getRadius() {
		return msocketGroupWriterInternalsObj.getRadius();
	}
	
	public void setStartTime(long start) {
		msocketGroupWriterInternalsObj.setStartTime(start);
	}
	
	public long getStartTime() {
		return msocketGroupWriterInternalsObj.getStartTime();
	}
	
	/**
	 * In msecs
	 * @param start
	 */
	public void setGroupUpdateDelay(int delay) {
		msocketGroupWriterInternalsObj.setGroupUpdateDelay(delay);
	}
	
	public long getGroupUpdateDelay() {
		return msocketGroupWriterInternalsObj.getGroupUpdateDelay();
	}
	
	public InputStream getInputStream() {
		if(mcIn == null) {
			mcIn = new MSocketGroupWriterInputStream(msocketGroupWriterInternalsObj);
		}
		return mcIn;
	}
	
	public OutputStream getOutputStream() {
		if(mcOut == null) {
			mcOut = new MSocketGroupWriterOutputStream(msocketGroupWriterInternalsObj);
		}
		return mcOut;
	}
	
}