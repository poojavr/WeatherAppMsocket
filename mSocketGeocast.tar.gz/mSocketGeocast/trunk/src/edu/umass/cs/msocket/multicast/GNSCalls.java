package edu.umass.cs.msocket.multicast;

import java.net.InetSocketAddress;
import java.security.KeyPair;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;


import edu.umass.cs.gns.client.AbstractGnsClient;
import edu.umass.cs.gns.client.GnsProtocol;
import edu.umass.cs.gns.client.GuidEntry;
import edu.umass.cs.gns.client.util.KeyPairUtils;
import edu.umass.cs.msocket.common.GnsConstants;
import edu.umass.cs.msocket.gns.GNSContactAddress;
import edu.umass.cs.msocket.gns.GnsCredentials;
import edu.umass.cs.msocket.gns.GnsIntegration;

public class GNSCalls {
	private static Logger log = Logger.getLogger(GNSCalls.class.getName());
	
	public static void updateMyLocationInGns(String localAlias, double Lat, double Longi)  {
		  
		  try {  
			   		GnsCredentials credentials = GnsIntegration.getCredentials();
					GuidEntry myGuid = KeyPairUtils.getGuidEntryFromPreferences(GNSContactAddress.GNSAddress, localAlias);		
					final AbstractGnsClient gnsClient = credentials.getGnsClient();
					gnsClient.setLocation(Longi, Lat, myGuid);
				
				} catch (Exception e) {
					e.printStackTrace();
				    log.trace("Location update didn't want to take place");
				}
	  }
		  
		  
	  public static JSONArray selectNear(JSONArray coordJson, double radius) throws Exception
		  {
		    GnsCredentials credentials =  GnsIntegration.getCredentials();

		    final AbstractGnsClient gnsClient = credentials.getGnsClient();

		    synchronized (gnsClient)
		    {
		        JSONArray queryResult = gnsClient.selectNear(GnsProtocol.LOCATION_FIELD_NAME, coordJson, radius);
		        log.trace("size of selected GUIDs "+ queryResult.length() );
		        
		        return queryResult;
		    }
		}
		  
		  
	  public static void writeKeyValue(String localName,
		      String key, String value) throws Exception
		  {
		    	GnsCredentials credentials = GnsIntegration.getCredentials();

		    log.trace("Looking for entity " + localName + " GUID and certificates...");
		    
		    GuidEntry myGuid = KeyPairUtils.getGuidEntryFromPreferences(GNSContactAddress.GNSAddress, localName);

		    final AbstractGnsClient gnsClient = credentials.getGnsClient();
		    String GNSKey   = key;
		    String GNSValue = value;
		    

		    synchronized (gnsClient)
		    {
		    
		    if (myGuid == null)
		      {
		        log.trace("No keys found for service " + localName
		            + ". Generating new GUID and keys");
		        // Create a new GUID and save it

		        myGuid = gnsClient.addGuid(credentials.getGuidEntry(), localName);	        
		        KeyPairUtils.saveKeyPairToPreferences(GNSContactAddress.GNSAddress, localName, myGuid.getGuid(),
		            new KeyPair(myGuid.getPublicKey(), myGuid.getPrivateKey()));

		        gnsClient.createField(myGuid, GnsConstants.ALIAS_FIELD, localName);

		        gnsClient.replaceOrCreate(myGuid, GNSKey, GNSValue);

		      }
		      else
		      {
		        log.trace("GUID already registered, just replacing the field value "
		            + localName + " values " + GNSValue);
		        
		        gnsClient.replaceOrCreate(myGuid, GNSKey, GNSValue);
		        
		      }
		    }
		 }
	  
	  
	  // commented code
	  /*public static String getKeyValue(String guid, String field, GnsCredentials gnsCredentials) throws Exception
	  {
	    if (gnsCredentials == null)
	      gnsCredentials = getCredentials();
	  
	    
	    AbstractGnsClient gnsClient = gnsCredentials.getGnsClient();

	    return gnsClient.readField(guid, field);
	    // log.trace("GUID lookup "+guidString);
	  }*/
}