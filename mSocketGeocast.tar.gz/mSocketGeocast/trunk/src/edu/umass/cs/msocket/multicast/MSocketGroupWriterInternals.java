/**
 * Mobility First - Global Name Resolution Service (GNS)
 * Copyright (C) 2013 University of Massachusetts - Emmanuel Cecchet.
 * Contact: cecchet@cs.umass.edu
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 *
 * Initial developer(s): Emmanuel Cecchet.
 * Contributor(s): ______________________.
 */

package edu.umass.cs.msocket.multicast;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import edu.umass.cs.msocket.MSocket;
import edu.umass.cs.msocket.gns.GnsIntegration;


public class MSocketGroupWriterInternals {
	
	public static final int GET = 	  1;
	public static final int PUT = 	  2;
	public static final int GET_ALL = 3;
	public static final int REMOVE  = 4;
	
	private String writerName = "";
	private String groupName ="";
	private double Lat = 0;
	private double Longi = 0;
	
	private double CHECK_RADIUS = 75;
	
	// group is calculated and updated per sec
	private int GROUP_UPDATE_DELAY = 1000;
	
	private HashMap<String, WriterMSocketInfo> memberConnectionMap = null;
	//private Thread listeningThread = null;
	private Vector<String> groupMembers = null;
	
	// for exp measurements
	private long startTime = 0;
	
	private static Logger log = Logger.getLogger(MSocketGroupWriterInternals.class.getName());
	
	
	public MSocketGroupWriterInternals(String writerName) throws Exception {
		this.writerName = writerName;
		groupMembers = new Vector<String>();
		
		memberConnectionMap = new HashMap<String, WriterMSocketInfo>();
		
		//GroupMemberMaintain grpObj = new GroupMemberMaintain(this);
		//new Thread(grpObj).start();
		
		// register group in GNS
	}
	
	public synchronized void createGroup() {
		
		System.out.println("group creation started");
		
		Vector<String> groupMembers = getGroupMembersGUIDs();
		groupMemberOperations(PUT, groupMembers);
		long end = System.currentTimeMillis();
		
		System.out.println("group creation complete "+(end - startTime) );
	}
	
	
	public synchronized void startGroupMaintainThread() {
		log.trace("starting group maintain thread");
		GroupMemberMaintain grpObj = new GroupMemberMaintain(this);
		new Thread(grpObj).start();
	}
	
	public String getGroupName() {
		return groupName;
	}
	
	public synchronized void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	public synchronized void setLocation(double Lat, double Longi) {
		this.Lat = Lat;
		this.Longi = Longi;
		
		//this.groupName = groupName;
	}
	
	public double getLat() {
		return this.Lat ;
	}
	
	public double getLongi() {
		return this.Longi ;
	}
	
	public void setRadius(double Radius) {
		CHECK_RADIUS = Radius;
		//msocketGroupWriterInternalsObj.setLocation(Lat, Longi);
	}
	
	public double getRadius() {
		return CHECK_RADIUS;
	}
	
	public void setStartTime(long start) {
		this.startTime = start;
	}
	
	public long getStartTime() {
		return this.startTime;
	}
	
	public void setGroupUpdateDelay(int delay) {
		GROUP_UPDATE_DELAY = delay;
	}
	
	public int getGroupUpdateDelay() {
		return GROUP_UPDATE_DELAY;
	}
	
	public synchronized Object writerConnectionMapOperations(int typeOfOper, String aliasMember, WriterMSocketInfo toPut) {
		switch(typeOfOper)
		{
			case GET:
			{
				return memberConnectionMap.get(aliasMember);
				//break;
			}
			
			case PUT:
			{
				//memberMSockets.add(toPut);
				//memberConnectionMap
				memberConnectionMap.put(aliasMember, toPut);
				break;
			}
			
			case GET_ALL:
			{
				//Vector<MSocket> retVector = new Vector<MSocket>();
				return memberConnectionMap.values();
				//break;
			}
			
			case REMOVE:
			{
				//Vector<MSocket> retVector = new Vector<MSocket>();
				return memberConnectionMap.remove(aliasMember);
				//break;
			}
		}
		return null;
	}
	
	public synchronized Object groupMemberOperations(int typeOfOper, Vector<String> toPut) {
		switch(typeOfOper)
		{
			case GET:
			{
				Vector<String> toReturn = new Vector<String>();
				toReturn.addAll(groupMembers);
				return toReturn;
				//break;
			}
			
			case PUT:
			{
				groupMembers.clear();
				groupMembers.addAll(toPut);
				break;
			}
		}
		return null;
	}
	
	private Vector<String> getGroupMembersGUIDs() {
		
		String selectQuery = getGroupName();
		String[] parsed =  selectQuery.split(":");
		String field = parsed[0];
		String value = parsed[1];
		Vector<String> currMem = new Vector<String>();
		
	    JSONArray coordJson = new JSONArray(Arrays.asList(getLongi(), getLat() ));
	    
	    try{
		    JSONArray queryResult = GNSCalls.selectNear(coordJson, getRadius());
		    for (int i = 0; i < queryResult.length(); i++) {
		    	try {
			        JSONObject record = queryResult.getJSONObject(i);
			        
			        
			        Iterator<?> keys = record.keys();

			        /*while( keys.hasNext() ){
			            String key = (String)keys.next();
			            
			            System.out.println("Keys of JSON Object "+key);
			            //if( jObject.get(key) instanceof JSONObject ){

			            //}
			        }*/
			        
			        
			        String guidString = record.getString("GUID");
			        String attrGNSValue = record.getString(field);
			        String compvalue = "[\""+ value+"\"]";
			        System.out.println("guidString "+guidString+" attrGNSValue "+attrGNSValue);
			        if( attrGNSValue.equals(compvalue) ) {
			        	currMem.add(guidString);
			        }
		    	} catch(Exception ex) {
		    		log.trace("field not found exception in JSON Object" + ex.toString());
		    		//ex.printStackTrace();
		    	}
		    }
	    } catch(Exception e) {
	    	e.printStackTrace();
	    }
	    return currMem;
	 }
	
	private class GroupMemberMaintain implements Runnable {
		private MSocketGroupWriterInternals msocketGroupWriterInternalsObj = null;
		
		public GroupMemberMaintain(MSocketGroupWriterInternals msocketGroupWriterInternalsObj) {
			this.msocketGroupWriterInternalsObj = msocketGroupWriterInternalsObj;
			
		}
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			while(true)
			{
				msocketGroupWriterInternalsObj.createGroup();
				try {
					Thread.sleep(GROUP_UPDATE_DELAY);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	
	/*private void regsiterGroupInGNS(String groupName) throws Exception {
	GnsIntegration.registerGroupInGNS(groupName, null);
	}*/
	
	/*private JSONArray collectNearbyGuids() {
    JSONArray guids = new JSONArray();
    JSONArray coordJson = new JSONArray(Arrays.asList(getLongi(), getLat() ));
    try {
	    JSONArray queryResult = GnsIntegration.selectNear(coordJson, getRadius(), null);
	    for (int i = 0; i < queryResult.length(); i++) {
	        JSONObject record = queryResult.getJSONObject(i);
	        String guidString = record.getString("GUID");
	        guids.put(guidString);
	    }
    }
    catch (Exception e) {
       e.printStackTrace();
    }
    return guids;
}

private Vector<String> groupMembershipCheck(JSONArray memberGuids) {
	
	int i=0;
	String selectQuery = getGroupName();
	String[] parsed =  selectQuery.split(":");
	String field = parsed[0];
	String value = parsed[1];
	Vector<String> currMem = new Vector<String>();
	
	for(i=0;i<memberGuids.length();i++) {
		try {
			String memberGUID = (String) memberGuids.get(i);
			
			//String alias = GnsIntegration.getAliasOfGUID(memberGUID, null);
			//log.trace("getting key value of "+alias);
			//log.trace("gp 1"+writerInternalObj.getGroupName()+" gpGNS "+GnsIntegration.getGroupNameFromGNS((String) memberGuids.get(i), null));
			if( GnsIntegration.getKeyValue( memberGUID, field, null).equals( value ) )
			{
				currMem.add(memberGUID);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.trace("excp in groupMembershipCheck");
			//e.printStackTrace();
		}
	}
	return currMem;
}*/

}