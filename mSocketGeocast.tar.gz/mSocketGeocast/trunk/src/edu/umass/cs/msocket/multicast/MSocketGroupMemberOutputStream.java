/**
 * Mobility First - Global Name Resolution Service (GNS)
 * Copyright (C) 2013 University of Massachusetts - Emmanuel Cecchet.
 * Contact: cecchet@cs.umass.edu
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 *
 * Initial developer(s): Emmanuel Cecchet.
 * Contributor(s): ______________________.
 */

package edu.umass.cs.msocket.multicast;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import edu.umass.cs.msocket.MServerSocket;
import edu.umass.cs.msocket.MSocket;
import edu.umass.cs.msocket.gns.GnsIntegration;

public class MSocketGroupMemberOutputStream extends OutputStream {
	
	private static final int POOL_SIZE = 10;
	
	private MSocketGroupMemberInternals msocketGroupMemberInternalsObj = null;
	private final ExecutorService     writePool;
	
	
	private static Logger log = Logger.getLogger(MSocketGroupWriterOutputStream.class.getName());
	
	
	public MSocketGroupMemberOutputStream(MSocketGroupMemberInternals msocketGroupMemberInternalsObj) {
		this.msocketGroupMemberInternalsObj = msocketGroupMemberInternalsObj;
		writePool = Executors.newCachedThreadPool();
		//writePool = Executors.newFixedThreadPool(POOL_SIZE);
		//newCachedThreadPool();
	}

	@Override
	public void write(int arg0) throws IOException {
		// TODO Auto-generated method stub
		//Integer argInt = arg0;
	}
	
	@Override
	public void write(byte[] b) throws IOException {
		// TODO Auto-generated method stub	
		write(b, 0, b.length);
	}
	
	@Override
	public void write(byte[] b, int offset, int length) throws IOException {
		
		// TODO Auto-generated method stub
		try {
		
			Vector<MSocket> accptSockets = new Vector<MSocket>();
			accptSockets.addAll((Collection<? extends MSocket>) msocketGroupMemberInternalsObj.memberConnectionMapOperations(MSocketGroupMemberInternals.GET_ALL, "",null));
			
			for(int i=0;i<accptSockets.size(); i++) {
				log.trace("writing to "+accptSockets.get(i));
				writePool.execute(new writeTask(accptSockets.get(i), b, offset, length, msocketGroupMemberInternalsObj ));
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	private class writeTask implements Runnable {
		private MSocket writeMSocket = null;
		private byte[] mesgArray = null;
		private int offset =0;
		private int length =0;
		
		
		private MSocketGroupMemberInternals msocketGroupMemberInternalsObj = null;
		
		public writeTask( MSocket writeMSocket, byte[] mesgArray, int offset, int length, 
				MSocketGroupMemberInternals msocketGroupMemberInternalsObj ) {	
			this.writeMSocket = writeMSocket;
			this.mesgArray = mesgArray;
			this.offset = offset;
			this.length = length;
			
			this.msocketGroupMemberInternalsObj = msocketGroupMemberInternalsObj;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub
			if(writeMSocket == null) {
				log.trace("returned socket info null, should not happen");
			}
			
			synchronized(writeMSocket)
			{
				try {
						writeMSocket.getOutputStream().write(mesgArray, offset, length);
						
				} catch (IOException e) {
					// TODO Auto-generated catch block
					log.trace("IO Exception recieved on MSocket write, socket is really in trouble, closing the current MSocket and opening a new one");
					//msocketocketGroupWriterInternalsObj.writerConnectionMapOperations
					//(MSocketGroupWriterInternals.REMOVE, aliasMember, null);
					writeMSocket = null;
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
	}
	
}