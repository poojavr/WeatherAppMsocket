/**
 * Mobility First - Global Name Resolution Service (GNS)
 * Copyright (C) 2013 University of Massachusetts - Emmanuel Cecchet.
 * Contact: cecchet@cs.umass.edu
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License. 
 *
 * Initial developer(s): Emmanuel Cecchet.
 * Contributor(s): ______________________.
 */

package edu.umass.cs.msocket.multicast;

import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import edu.umass.cs.msocket.MSocket;

public class MSocketGroupMemberInputStream extends InputStream {
	
	private static final int QUEUE_POP  =  		1;
	private static final int QUEUE_PUSH =  		2;
	private static final int QUEUE_SIZE =  		3;
	
	private static final int POOL_SIZE = 10;
	
	// maximum size of read chunk
	private static final int READ_CHUNK = 1000;
	
	
	private MSocketGroupMemberInternals msocketGroupMemberInternalsObj = null;
	private final ExecutorService     readPool;
	
	private final Object queueMonitor = new Object();
	
	private Queue<byte[]> readQueue = null;
	
	
	
	private static Logger log = Logger.getLogger(MSocketGroupMemberInputStream.class.getName());
	
	public MSocketGroupMemberInputStream(
		MSocketGroupMemberInternals msocketGroupMemberInternalsObj) {
		// TODO Auto-generated constructor stub
		this.msocketGroupMemberInternalsObj = msocketGroupMemberInternalsObj;
		readPool = Executors.newCachedThreadPool();
		//readPool = Executors.newFixedThreadPool(POOL_SIZE);
		
		readQueue = new LinkedList<byte[]>();
	}

	@Override
	public int read() throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public int read(byte[] b) throws IOException {
		// TODO Auto-generated method stub
		//return read(b, 0, b.length);
		return 0;
	}
	
	
	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}
	
	/**
	 * reads from any of the writer and returns the byte array
	 * TODO: readAny definition.
	 * 
	 * @return
	 * @throws IOException
	 */
	public byte[] readAny() throws IOException {
		// TODO Auto-generated method stub
		Vector<MSocket> currMSockets = new Vector<MSocket>();
		currMSockets.addAll( (Collection<? extends MSocket>) msocketGroupMemberInternalsObj.memberConnectionMapOperations(
				MSocketGroupMemberInternals.GET_ALL, "", null));
		log.trace("currMSockets size "+currMSockets.size());
		
		synchronized(msocketGroupMemberInternalsObj.accptMonitor) {
			while(currMSockets.size() == 0)
			{
				try {
					msocketGroupMemberInternalsObj.accptMonitor.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				currMSockets.clear();
				currMSockets.addAll( (Collection<? extends MSocket>) msocketGroupMemberInternalsObj.memberConnectionMapOperations(
						MSocketGroupMemberInternals.GET_ALL, "", null));
				log.trace("currMSockets size "+currMSockets.size());
			}
		}
		
		for(int i=0; i<currMSockets.size(); i++) {
			readPool.execute(new readTask(currMSockets.get(i), msocketGroupMemberInternalsObj ));
			//readMSocket(currMSockets.get(i));
		}
		
		synchronized(queueMonitor)
		{
			while( (Integer)readQueueOperations(QUEUE_SIZE, null) == 0 ) {	
				try {
					queueMonitor.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		byte[] retByte = (byte[]) readQueueOperations(QUEUE_POP, null);
	 	return retByte;
	}
	
	public synchronized Object readQueueOperations(int typeOper, byte[] toPut) {
		switch(typeOper) {
			
			case QUEUE_POP: 
			{
				return readQueue.poll();
				//break;
			}
			case QUEUE_PUSH: 
			{
				readQueue.add(toPut);
				break;
			}
			case QUEUE_SIZE: 
			{
				return readQueue.size();
				//break;
			}
		}
		return null;
	}
	
	
	private class readTask implements Runnable {
		
		private MSocket readMSocket = null;
		//private String aliasMember = "";
		private MSocketGroupMemberInternals msocketGroupMemberInternalsObj = null;
		
		public readTask( MSocket readMSocket, MSocketGroupMemberInternals msocketGroupMemberInternalsObj ) {
			this.readMSocket = readMSocket;
			this.msocketGroupMemberInternalsObj = msocketGroupMemberInternalsObj;
		}

		@Override
		public void run() {
			// TODO Auto-generated method stub
				
				try {
					byte[] readBuf = new byte[READ_CHUNK];
					
					while(true)
					{
						log.trace("started reading");
						int numRead = readMSocket.getInputStream().read(readBuf, 0, readBuf.length);
						log.trace("ended reading");
						if(numRead > 0) 
						{
							byte[] storeBuf = new byte[numRead];
							System.arraycopy(readBuf, 0, storeBuf, 0, numRead);
							
							readQueueOperations(QUEUE_PUSH, storeBuf);
							break;
						} else{
							continue;
						}
					}
					
					synchronized(queueMonitor) {
						queueMonitor.notifyAll();
					}
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}