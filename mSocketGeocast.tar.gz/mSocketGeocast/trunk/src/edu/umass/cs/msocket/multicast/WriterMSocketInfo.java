package edu.umass.cs.msocket.multicast;

import edu.umass.cs.msocket.MSocket;

public class WriterMSocketInfo {
	
	public final Object writeMonitor = new Object(); 
	public final Object readMonitor = new Object();
	
	private final String aliasMember;
	private MSocket memberMSocket = null;
	private boolean writeProg = true;
	
	
	
	
	public String getAlias() {
		return aliasMember;
	}
	
	public MSocket getMemberMSocket() {
		return memberMSocket;
	}
	
	public WriterMSocketInfo(String aliasMember) {
		this.aliasMember = aliasMember;
	}
	
	public void setMemberMSocket(MSocket memberMSocket) {
		this.memberMSocket = memberMSocket;
	}
	
}
